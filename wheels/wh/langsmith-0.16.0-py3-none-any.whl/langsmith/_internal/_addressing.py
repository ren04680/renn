"""Resolving whether a run is addressed by project or by address.

A run goes to exactly one destination: a project (`project_name`) or an
address (`langsmith.agent_address(id, environment)`), which
names an agent and one of its environments. The server resolves an address to
the agent environment's project, so traces follow the agent rather than a
project name. Project addressing keeps working alongside it.

A run with a parent, in-process or from distributed-tracing headers, joins its
parent's destination. A root run takes the first of these levels that names a
project or an address, whichever it names; naming both at one level raises:

1. `tracing_context`
2. `langsmith_extra`
3. the `@traceable` / `trace` arguments
4. `configure`
5. the env vars (`LANGSMITH_PROJECT`, `LANGSMITH_AGENT_*`)

In code the address is an `AgentAddress`: in context variables, run trees and
replicas. It becomes its LRN string only on the wire, in the `address` payload
field, which is set only here, in `apply_to_payload` and
`FeedbackCreate.model_dump`, and in the `langsmith-address` baggage entry.
"""

from __future__ import annotations

import functools
import logging
import re
import warnings
from collections.abc import Mapping
from typing import Any, Optional

from langsmith import address as _address
from langsmith import utils
from langsmith.address import AgentAddress, EnvAddressError

_LOGGER = logging.getLogger(__name__)

# The wire form of an agent address. The parts are validated by `agent_address`.
_LRN_PATTERN = re.compile(r"lrn:agents/([^/]+)/environments/([^/]+)")


def check_address(address: Any) -> Optional[AgentAddress]:
    """Return `address` if it is an `AgentAddress`, or `None` if it is `None`.

    Raises:
        utils.LangSmithUserError: If `address` is not an `AgentAddress`.
    """
    return None if address is None else _address.ensure_agent(address)


def check_lookup_address(address: Any) -> Optional[_address.Address]:
    """Return `address` if it is an `Address` of any kind, or `None` if it is `None`.

    For the calls that resolve an address to its project, which take any kind.

    Raises:
        utils.LangSmithUserError: If `address` is not an `Address`.
    """
    return None if address is None else _address.ensure_address(address)


def normalize_replicas(replicas: Optional[Any]) -> Optional[list]:
    """Put a bare `AgentAddress` replica in an `address` key, and check the rest."""
    if replicas is None:
        return None
    normalized = []
    for replica in replicas:
        if not isinstance(replica, Mapping) or "kind" in replica:
            normalized.append({"address": check_address(replica)})
            continue
        normalized_replica = dict(replica)
        if replica.get("address") is not None:
            normalized_replica["address"] = check_address(replica["address"])
        normalized.append(normalized_replica)
    return normalized


def address_to_lrn(address: AgentAddress) -> str:
    """Convert a validated agent address to its ingestion wire identifier."""
    return f"lrn:agents/{address['id']}/environments/{address['environment'].lower()}"


def address_from_lrn(value: Any) -> AgentAddress:
    """Parse an untrusted wire identifier without echoing it in errors."""
    match = _LRN_PATTERN.fullmatch(value) if isinstance(value, str) else None
    if match is None:
        raise utils.LangSmithUserError("Not an agent address.")
    return _address.agent_address(*match.groups())


Tier = tuple[Optional[str], Optional[AgentAddress]]
"""One precedence level: the `(project, address)` it names, either may be unset."""

# Defined in `langsmith.address`, whose public `resolve_destination` wraps them and which
# this module imports, so it cannot import this module back.
resolve = _address._resolve
_both_at_one_level = _address._both_at_one_level


def first_named(*tiers: Tier) -> Tier:
    """Return the highest level that names a destination, without the env vars.

    Raises:
        utils.LangSmithUserError: If that level names both.
    """
    for level, (project, address) in enumerate(tiers, start=1):
        if project and address is not None:
            raise _both_at_one_level(project, address, f"at precedence level {level}")
        if project or address is not None:
            return project or None, address
    return None, None


def otlp_destination_headers(project: Optional[str], address: Optional[AgentAddress]) -> dict[str, str]:
    """Return the OTLP headers that send an export to a project or an agent.

    The values come only from a validated `AgentAddress`, so a caller's string
    never reaches a header unchecked. The backend rejects an export that names
    both, so `address` wins here rather than sending both.
    """
    if address is not None:
        return {
            "Langsmith-Agent-Id": address["id"],
            "Langsmith-Agent-Environment": address["environment"].lower(),
        }
    return {"Langsmith-Project": project} if project else {}


def log_untraced(error: EnvAddressError) -> None:
    """Log, once per distinct cause, that calls run untraced for a bad env."""
    _log_untraced_once(str(error))


@functools.cache
def _log_untraced_once(message: str) -> None:
    _LOGGER.warning("LangSmith is not tracing this call: %s", message)


def warn_on_env() -> None:
    """Warn when the environment's address cannot be used.

    Half an address, an invalid one, or one beside a configured project, leaves
    calls that name nothing in code untraced -- and a name like
    `LANGSMITH_AGENT_ENVIRONMENT` is generic enough to be set by accident.

    Emitted at client construction rather than per run, so it is seen once.
    """
    present = [name for name, value in _address.env_values().items() if value]
    if not present:
        return
    try:
        address = _address.address_from_env()
    except EnvAddressError as e:
        warnings.warn(
            f"{e} Calls that name no destination in code are not traced.",
            utils.LangSmithWarning,
            stacklevel=3,
        )
        return
    if address is None:
        return
    project = utils.get_tracer_project(return_default_value=False)
    if project is None:
        return
    warnings.warn(
        f"The address from LANGSMITH_AGENT_ID and LANGSMITH_AGENT_ENVIRONMENT "
        f"({address!r}) and a configured "
        f"project ({project!r}) are both set in the environment, so calls that name "
        "no destination in code are not traced. Unset one of them.",
        utils.LangSmithWarning,
        stacklevel=3,
    )


def reject_conflicting(
    *,
    project: Optional[Any] = None,
    session_id: Optional[Any] = None,
    address: Optional[_address.Address] = None,
) -> None:
    """Reject a call that names both a project and an address.

    Pass only values the caller supplied in this call: an inherited or
    ambient address beside an explicit project is not a conflict -- the project
    wins, which is what lets an evaluation set its own project while
    `LANGSMITH_AGENT_ID` is set process-wide.

    Raises:
        utils.LangSmithUserError: If a project and an address are both named.
    """
    named_project = project if project is not None else session_id
    if named_project is not None and address is not None:
        raise utils.LangSmithUserError(
            f"A run is addressed by project ({named_project!r}) or by address ({address!r}), not both."
        )


def apply_to_payload(payload: dict, *, update: bool = False) -> None:
    """Put a run payload's address in its wire field, as its LRN string.

    The one place a run's `address` is settled. A project already on the
    payload addresses the run, so the environment is not consulted. With no
    project, an ambient address fills in and the null project keys are dropped.

    On an update the environment is not consulted: a patch inherits its
    address from the post that established it, and one naming nothing is
    resolved by run id.
    """
    address = payload.pop("address", None)
    if isinstance(address, str):
        # Wire data already applied: a retried batch re-sends it. It is parsed
        # again, so a malformed one cannot fail the whole batch in the backend.
        try:
            address = address_from_lrn(address)
        except utils.LangSmithUserError:
            raise utils.LangSmithUserError("The run's `address` is not a valid agent address.") from None
    else:
        address = check_address(address)
    named_project = payload.get("session_id") is not None or payload.get("session_name") is not None
    if address is None and not (update or named_project):
        address = _address.address_from_env()
    if address is None:
        return
    payload["address"] = address_to_lrn(address)
    if not named_project:
        payload.pop("session_name", None)
        payload.pop("session_id", None)
