# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel

__all__ = [
    "AnnotationQueueRubricItemSchema",
    "FeedbackConfig",
    "FeedbackConfigFeedbackConfig",
    "FeedbackConfigFeedbackConfigCategory",
    "RequiredIf",
    "RequiredIfRule",
    "VisibleIf",
    "VisibleIfRule",
]


class FeedbackConfigFeedbackConfigCategory(BaseModel):
    """Specific value and label pair for feedback"""

    value: float

    label: Optional[str] = None


class FeedbackConfigFeedbackConfig(BaseModel):
    type: Literal["continuous", "categorical", "freeform"]
    """Enum for feedback types."""

    allows_multiple_categories: Optional[bool] = None
    """Whether a reviewer can pick several categories. Categorical feedback only."""

    categories: Optional[List[FeedbackConfigFeedbackConfigCategory]] = None

    max: Optional[float] = None

    min: Optional[float] = None


class FeedbackConfig(BaseModel):
    id: str

    feedback_config: FeedbackConfigFeedbackConfig

    feedback_key: str

    modified_at: datetime

    tenant_id: str

    is_deleted: Optional[bool] = None

    is_enforced: Optional[bool] = None

    is_first: Optional[bool] = None

    is_lower_score_better: Optional[bool] = None


class RequiredIfRule(BaseModel):
    key: str

    op: Literal["is", "is_one_of", "is_empty", "is_not_empty"]

    values: Optional[List[float]] = None


class RequiredIf(BaseModel):
    join: Literal["all", "any"]

    rules: List[RequiredIfRule]


class VisibleIfRule(BaseModel):
    key: str

    op: Literal["is", "is_one_of", "is_empty", "is_not_empty"]

    values: Optional[List[float]] = None


class VisibleIf(BaseModel):
    join: Literal["all", "any"]

    rules: List[VisibleIfRule]


class AnnotationQueueRubricItemSchema(BaseModel):
    feedback_key: str

    description: Optional[str] = None

    feedback_config: Optional[FeedbackConfig] = None

    feedback_config_id: Optional[str] = None

    is_assertion: Optional[bool] = None

    is_required: Optional[bool] = None

    regex_validator: Optional[str] = None

    required_if: Optional[RequiredIf] = None

    score_descriptions: Optional[Dict[str, str]] = None

    value_descriptions: Optional[Dict[str, str]] = None

    visible_if: Optional[VisibleIf] = None
